#ifndef MYWIDGET_H
#define MYWIDGET_H
 
#include <QtGui>
#include <QWidget>
#include "SimOptions.h"
#include "SimController.h"
#include <stdexcept>
class LifeDrawingWidget : public QWidget{
    Q_OBJECT
public:
    LifeDrawingWidget(LifeGUISimOptions *options, SimController *ctrl);
    virtual ~LifeDrawingWidget(){} 
protected:
	LifeGUISimOptions *opts; 
	SimController *controller;
    void paintEvent(QPaintEvent *event);
signals:
 
public slots:
 
};
 
#endif // MYWIDGET_H
